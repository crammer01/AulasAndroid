package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

public class Combos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combos);
        try {

            SQLiteDatabase bancoDadosCombo = openOrCreateDatabase("app", MODE_PRIVATE, null);

            //tabela
            bancoDadosCombo.execSQL("CREATE TABLE IF NOT EXISTS COMBO( id INTEGER PRIMARY KEY AUTOINCREMENT, sabor VARCHAR)");

            //Inserir dados
            bancoDadosCombo.execSQL("INSERT INTO COMBO (sabor) VALUES ('Bacon com Coca Cola')");

            Cursor cursor = bancoDadosCombo.rawQuery("SELECT * FROM COMBO ", null);

            int indiceColunaNome = cursor.getColumnIndex("sabor");
            int indiceColunaId = cursor.getColumnIndex("id");

            cursor.moveToFirst();

            while (cursor != null) {
                Toast.makeText(this, cursor.getString(indiceColunaNome), Toast.LENGTH_SHORT).show();
                cursor.moveToNext();
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
