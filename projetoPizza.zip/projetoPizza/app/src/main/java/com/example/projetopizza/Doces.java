package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

public class Doces extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doces);

        try {

            SQLiteDatabase bancoDadosDoces = openOrCreateDatabase("app", MODE_PRIVATE, null);

            //tabela
            bancoDadosDoces.execSQL("CREATE TABLE IF NOT EXISTS DOCE( id INTEGER PRIMARY KEY AUTOINCREMENT, sabor VARCHAR)");

            //Inserir dados
            bancoDadosDoces.execSQL("INSERT INTO DOCE (sabor) VALUES ('Amendoin')");

            Cursor cursor = bancoDadosDoces.rawQuery("SELECT * FROM DOCE ", null);

            int indiceColunaNome = cursor.getColumnIndex("sabor");
            int indiceColunaId = cursor.getColumnIndex("id");

            cursor.moveToFirst();

            while (cursor != null) {
                Toast.makeText(this, cursor.getString(indiceColunaNome), Toast.LENGTH_SHORT).show();
                cursor.moveToNext();
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }
}
