package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Bebidas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bebidas);
    }
}
