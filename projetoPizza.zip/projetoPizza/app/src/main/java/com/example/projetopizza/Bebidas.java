package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

public class Bebidas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bebidas);

        try {

            SQLiteDatabase bancoDadosBebida = openOrCreateDatabase("app", MODE_PRIVATE, null);

            //tabela
            bancoDadosBebida.execSQL("CREATE TABLE IF NOT EXISTS BEBIDA( id INTEGER PRIMARY KEY AUTOINCREMENT, sabor VARCHAR)");

            //Inserir dados
            bancoDadosBebida.execSQL("INSERT INTO BEBIDA (sabor) VALUES ('Coca Cola')");

            Cursor cursor = bancoDadosBebida.rawQuery("SELECT * FROM BEBIDA ", null);

            int indiceColunaNome = cursor.getColumnIndex("sabor");
            int indiceColunaId = cursor.getColumnIndex("id");

            cursor.moveToFirst();

            while (cursor != null) {
                Toast.makeText(this, cursor.getString(indiceColunaNome), Toast.LENGTH_SHORT).show();
                cursor.moveToNext();
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }
}
