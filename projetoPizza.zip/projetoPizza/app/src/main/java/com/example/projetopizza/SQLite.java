package com.example.projetopizza;

public class SQLite {

    String nome;
    int id;

    public SQLite(){

    }

    public SQLite(int _id, String _nome){
        this.id = _id;
        this.nome = _nome;
    }
    public SQLite(String _nome){
        this.nome = _nome;
    }

    //==============================================================================================

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}


