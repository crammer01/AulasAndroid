package com.example.projetopizza;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

public class Pizza extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza);

        try {

            SQLiteDatabase bancoDadosPizza = openOrCreateDatabase("app", MODE_PRIVATE, null);

            //tabela
            bancoDadosPizza.execSQL("CREATE TABLE IF NOT EXISTS PIZZA( id INTEGER PRIMARY KEY AUTOINCREMENT, sabor VARCHAR)");

            //Inserir dados
            bancoDadosPizza.execSQL("INSERT INTO PIZZA (sabor) VALUES ('Bacon com calabresa')");

            Cursor cursor = bancoDadosPizza.rawQuery("SELECT * FROM PIZZA ", null);

            int indiceColunaNome = cursor.getColumnIndex("sabor");
            int indiceColunaId = cursor.getColumnIndex("id");

            cursor.moveToFirst();

            while (cursor != null) {
                Toast.makeText(this, cursor.getString(indiceColunaNome), Toast.LENGTH_SHORT).show();
                cursor.moveToNext();
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }
}
